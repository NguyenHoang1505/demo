import gradio as gr
from fastcoref import FCoref

model = FCoref(device='cpu')

def coreference_resolution(text):
    preds = model.predict(texts=[text])
    clusters = preds[0].get_clusters()
    
    cluster_output = ""
    for i, cluster in enumerate(clusters, start=1):
        cluster_output += f"Cluster {i}: {', '.join(cluster)}\n"
    
    return cluster_output

iface = gr.Interface(
    fn=coreference_resolution,
    inputs="text",
    outputs="text",
    title="Coreference Resolution - Nhóm 9"  # Add a title
)

iface.launch(share=True)
